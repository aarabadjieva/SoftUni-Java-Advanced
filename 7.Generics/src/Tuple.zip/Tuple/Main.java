package Tuple;

import Tuple.Tuple;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] first = scanner.nextLine().split("\\s+");
        String[] second = scanner.nextLine().split("\\s+");
        String[] third = scanner.nextLine().split("\\s+");
        Tuple<String, String> nameAndAdress= new Tuple<>(first[0]+" "+first[1],first[2]);
        Tuple<String, Integer> beerTuple = new Tuple<>(second[0],Integer.parseInt(second[1]));
        Tuple<Integer, Double> numbers = new Tuple<>(Integer.parseInt(third[0]),Double.parseDouble(third[1]));
        System.out.println(nameAndAdress.toString());
        System.out.println(beerTuple.toString());
        System.out.println(numbers.toString());
    }
}
