package Generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box> boxes = new ArrayList<>();
        while (n-->0){
            String line = scanner.nextLine();
            Box box = null;
            try{
                int number = Integer.parseInt(line);
                box = new Box<Integer>(number);
            }catch (Exception e){
                box = new Box<>(line);
            }

            boxes.add(box);
        }
        int[] indexes = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        boxes = swap(boxes,indexes[0], indexes[1]);
        for (Box box:boxes
             ) {
            System.out.println(box.toString());
        }
    }
    public static List<Box> swap(List<Box> boxes, int firstIndex, int secondIndex){
        Box temp = boxes.get(firstIndex);
        boxes.set(firstIndex, boxes.get(secondIndex));
        boxes.set(secondIndex, temp);
        return boxes;
    }
}
