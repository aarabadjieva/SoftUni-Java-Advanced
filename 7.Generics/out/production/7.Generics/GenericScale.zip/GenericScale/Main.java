package GenericScale;

public class Main {
    public static void main(String[] args) {
        Scale<String> scale = new Scale<>("hghgh", "utuyi8");
        System.out.println(scale.getHeavier());
    }
}
