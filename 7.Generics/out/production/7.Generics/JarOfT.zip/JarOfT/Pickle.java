package JarOfT;

public class Pickle {
    private String name;
    private int hardness;

    public Pickle() {
        this.name = "";
        this.hardness = 0;
    }
}
