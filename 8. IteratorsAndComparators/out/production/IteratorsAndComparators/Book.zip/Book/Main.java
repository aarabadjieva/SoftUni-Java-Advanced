package Book;

public class Main {
    public static void main(String[] args) {
        Book book = new Book("pesho", 1999, "gosho","pesho","stoqn");
        Book book1 = new Book("Maria", 1888);

    }
}
