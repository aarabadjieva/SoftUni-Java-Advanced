package ListIterator;

import java.util.ArrayList;
import java.util.List;

public class ListIterator {
    private static final int DEFAULT_INDEX = -1;
    private List<String> elements;
    private int index;

    public ListIterator(List<String> elements){
        this.elements = elements;
        this.setIndex();
    }

    private void setIndex() {
        if (this.elements.size()==0){
            this.index = ListIterator.DEFAULT_INDEX;
        }else {
            this.index = 0;
        }
    }

    public boolean move() {
        if (this.index<this.elements.size()-1){
            this.index++;
            return true;
        }
        return false;
    }

    public boolean hasNext() {
        if (this.index+1<this.elements.size()){
            return true;
        }
        return false;
    }

    public String print() {
        if (this.elements.size()==0){
            throw new IndexOutOfBoundsException("Invalid Operation!");
        }
        return this.elements.get(this.index);
    }
}
